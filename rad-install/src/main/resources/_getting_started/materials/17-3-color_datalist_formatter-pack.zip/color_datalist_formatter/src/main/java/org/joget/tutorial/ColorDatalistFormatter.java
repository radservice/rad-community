/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.joget.tutorial;

import net.purwana.rads.apps.app.service.AppPluginUtil;
import net.purwana.rads.apps.app.service.AppUtil;
import net.purwana.rads.apps.datalist.model.DataList;
import net.purwana.rads.apps.datalist.model.DataListColumn;
import net.purwana.rads.apps.datalist.model.DataListColumnFormatDefault;
import net.purwana.rads.commons.util.LogUtil;

/**
 *
 * @author aadrian
 */
public class ColorDatalistFormatter extends DataListColumnFormatDefault {

    private final static String MESSAGE_PATH = "messages/ClrDatalistFormatter";

    public String getName() {
        return "Color Datalist Formatter";
    }

    public String getVersion() {
        return "7.0.0";
    }

    public String getDescription() {
        //support i18n
        return AppPluginUtil.getMessage("org.joget.tutorial.ClrDatalistFormatter.pluginDesc", getClassName(), MESSAGE_PATH);
    }

    public String format(DataList dataList, DataListColumn column, Object row, Object value) {
        String result = (String) value;
 
        if (result != null && !result.isEmpty()) {
            try {
                String fontColor = "white";                
                
                if (getPropertyString("fontColor") != null && !getPropertyString("fontColor").isEmpty()) {
                    fontColor = getPropertyString("fontColor");                       
                }
                
                boolean isShowLabel = true;
                if (getPropertyString("showLabel") != null) {
                    isShowLabel = Boolean.parseBoolean(getPropertyString("showLabel"));                    
                }
                
                result = "";

                //suport for multi values
                for (String v : value.toString().split(";")) {
                    if (!v.isEmpty()) {
                        String rowValue = v;
                        
                        String rowStyle = "<p style=\"color:" + fontColor + "; background-color:" + rowValue + ";\">";
                        
                        if (isShowLabel) {
                            result += rowStyle + rowValue + "</p> ";
                        } else {
                            result += rowStyle+ "&nbsp;</p> ";                            
                        }
                         
                    }
                }
            } catch (Exception e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        
        return result;
    }

    public String getLabel() {
        //support i18n
        return AppPluginUtil.getMessage("org.joget.tutorial.ClrDatalistFormatter.pluginLabel", getClassName(), MESSAGE_PATH);
    }

    public String getClassName() {
        return getClass().getName();
    }

    public String getPropertyOptions() {
        return AppUtil.readPluginResource(getClassName(), "/properties/ClrDatalistFormatter.json", null, true, MESSAGE_PATH);
    }
}
