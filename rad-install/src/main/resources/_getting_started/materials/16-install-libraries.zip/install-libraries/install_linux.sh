./apache-ant-1.7.1/bin/ant -f lib/setup-maven_linux.xml
